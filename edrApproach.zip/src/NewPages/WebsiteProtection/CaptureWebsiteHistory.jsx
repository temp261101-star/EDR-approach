import React from 'react'

function CaptureWebsiteHistory() {
  return (
    <div>
      CaptureWebsiteHistory
    </div>
  )
}

export default CaptureWebsiteHistory
