import React from 'react'

const ViewApplication = () => {
  return (
    <div>ViewApplication</div>
  )
}

export default ViewApplication