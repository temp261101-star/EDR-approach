import React from 'react'

const ManageBlackListed = () => {
  return (
    <div>ManageBlackListed</div>
  )
}

export default ManageBlackListed