import React from 'react'

const PreventedApplicationReport = () => {
  return (
    <div>PreventedApplicationReport</div>
  )
}

export default PreventedApplicationReport