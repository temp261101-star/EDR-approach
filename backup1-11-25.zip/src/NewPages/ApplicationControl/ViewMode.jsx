import React from 'react'

const ViewMode = () => {
  return (
    <div>ViewMode</div>
  )
}

export default ViewMode