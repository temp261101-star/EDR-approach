import React from 'react'

const WhiteListedApplication = () => {
  return (
    <div>WhiteListedApplication</div>
  )
}

export default WhiteListedApplication