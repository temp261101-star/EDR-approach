import React from 'react'

function DownloadBrowserHistoryReport() {
  return (
    <div>
      DownloadBrowserHistory
    </div>
  )
}

export default DownloadBrowserHistoryReport
